# Free deployment

1. Create a free GitHub account.
2. Create a new public repository.
3. Upload index.html, styles.css and script.js.
4. Open Settings > Pages.
5. Choose Deploy from a branch, select main and /root, then Save.
6. GitHub will provide your free website URL.

The email buttons open Gmail Compose and there is also a copy-email fallback.
